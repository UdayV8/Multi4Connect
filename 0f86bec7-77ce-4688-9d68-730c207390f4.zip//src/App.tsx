import React, { useState, useEffect } from "react";
import LandingPage from "@/components/LandingPage";
import GameSelection from "@/components/GameSelection";
import GameBoard from "@/components/GameBoard";
import LoadingScreen from "@/components/LoadingScreen";
import "@styles/global.css";
import "@styles/game.css";

type GameConfig = {
  playerCount: 4 | 6 | 8;
  gameMode: "single" | "local";
  gameType: "casual" | "ranked";
  teamMode: "ffa" | "teams";
  boardType: "random" | "custom";
  gameOptions: string[];
};

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<
    "loading" | "landing" | "selection" | "game"
  >("loading");
  const [loadingProgress, setLoadingProgress] = useState(0);
  const [gameConfig, setGameConfig] = useState<GameConfig | null>(null);

  useEffect(() => {
    const interval = setInterval(() => {
      setLoadingProgress((prev) => {
        const newProgress = prev + Math.random() * 15;
        if (newProgress >= 100) {
          clearInterval(interval);
          return 100;
        }
        return newProgress;
      });
    }, 300);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (loadingProgress >= 100) {
      const timer = setTimeout(() => setCurrentView("landing"), 800);
      return () => clearTimeout(timer);
    }
  }, [loadingProgress]);

  useEffect(() => {
    console.log("Current view changed to:", currentView);
  }, [currentView]);

  const handleStartGame = (config: GameConfig) => {
    setGameConfig(config);
    setCurrentView("game");
  };

  // Add a container class to scope the game styles when in game view
  const getContainerClass = () => {
    return currentView === "game" ? "game-view-active" : "";
  };

  return (
    <div className={getContainerClass()}>
      {currentView === "loading" && (
        <LoadingScreen progress={loadingProgress} />
      )}
      {currentView === "selection" && (
        <GameSelection
          onClose={() => setCurrentView("landing")}
          onStart={handleStartGame}
        />
      )}
      {currentView === "game" && gameConfig ? (
        <GameBoard
          config={gameConfig}
          onExit={() => setCurrentView("selection")}
        />
      ) : currentView === "landing" ? (
        <LandingPage onPlay={() => setCurrentView("selection")} />
      ) : null}
    </div>
  );
};

export default App;
