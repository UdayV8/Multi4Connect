import React, { useState, useEffect, useRef } from "react"; // Added useRef here
import "@styles/loading.css";

interface LoadingScreenProps {
  progress: number;
}

const LoadingScreen: React.FC<LoadingScreenProps> = ({ progress }) => {
  const [floatingElements_1] = useState(() =>
    Array.from({ length: 20 }, (_, i) => ({
      id: i,
      type: i % 3 === 0 ? "coin_1" : "star_1",
      size: i % 3 === 0 ? 15 + Math.random() * 20 : 3 + Math.random() * 8,
      left: Math.random() * 100,
      top: Math.random() * 100,
      delay: Math.random() * 5,
      duration: 10 + Math.random() * 20,
      opacity:
        i % 3 === 0 ? 0.4 + Math.random() * 0.3 : 0.6 + Math.random() * 0.3,
    }))
  );

  const [trail_1, setTrail_1] = useState<{ x: number; y: number }[]>([]);
  const [currentTip_1, setCurrentTip_1] = useState(0);
  const [showShootingStars_1, setShowShootingStars_1] = useState(false);
  const [cursorPosition_1, setCursorPosition_1] = useState({ x: 0, y: 0 });
  const [showTimeoutPopup, setShowTimeoutPopup] = useState(false);
  const loadingTimeoutRef = useRef<NodeJS.Timeout>();

  const tips_1 = [
    "Pro Tip: Play the AI daily to get stronger",
    "Did you know? Team matches are hareder",
    "Suggestion? Share your ideas with us",
    "Coming Soon: Save progress with accounts",
  ];

  useEffect(() => {
    const timer = setTimeout(() => setShowShootingStars_1(true), 1000);

    // Set timeout for 5 seconds
    loadingTimeoutRef.current = setTimeout(() => {
      if (progress < 100) {
        setShowTimeoutPopup(true);
      }
    }, 5000);

    return () => {
      clearTimeout(timer);
      clearTimeout(loadingTimeoutRef.current);
    };
  }, [progress]);

  useEffect(() => {
    const tipInterval = setInterval(() => {
      setCurrentTip_1((prev) => (prev + 1) % tips_1.length);
    }, 1250);
    return () => clearInterval(tipInterval);
  }, [tips_1.length]);

  const handleMouseMove_1 = (e: React.MouseEvent) => {
    setCursorPosition_1({ x: e.clientX, y: e.clientY });
    setTrail_1((prev) => [...prev.slice(-5), { x: e.clientX, y: e.clientY }]);
  };

  return (
    <div
      className="loading-screen_1"
      onMouseMove={handleMouseMove_1}
      style={{ cursor: "none" }}
    >
      <div
        className="mouse-trailer_1"
        style={{
          left: `${cursorPosition_1.x}px`,
          top: `${cursorPosition_1.y}px`,
        }}
      ></div>

      <div className="cosmic-pulse_1"></div>

      {floatingElements_1.map((el) => (
        <div
          key={el.id}
          className={`loading-floating_1 loading-${el.type}`}
          style={{
            left: `${el.left}%`,
            top: `${el.top}%`,
            width: `${el.size}px`,
            height: `${el.size}px`,
            animationDuration: `${el.duration}s`,
            animationDelay: `${el.delay}s`,
            opacity: el.opacity,
          }}
        />
      ))}

      {showShootingStars_1 &&
        [...Array(3)].map((_, i) => (
          <div
            key={`shooting-${i}`}
            className="loading-shooting-star_1"
            style={{
              left: `${Math.random() * 20}%`,
              top: `${Math.random() * 20}%`,
              animationDelay: `${i * 2}s`,
            }}
          />
        ))}

      {trail_1.map((pos, i) => (
        <div
          key={i}
          className="loading-trail_1"
          style={{
            left: `${pos.x}px`,
            top: `${pos.y}px`,
            opacity: 0.3 + (i / trail_1.length) * 0.7,
            transform: `translate(-50%, -50%) scale(${
              0.3 + (i / trail_1.length) * 0.7
            })`,
          }}
        />
      ))}

      <div className="loading-content_1">
        <div className="loading-header_1">
          <h1 className="loading-title_1">
            <span>Multi</span>
            <span className="loading-highlight_1">4</span>
            <span>Connect</span>
          </h1>
          <p className="loading-subtitle_1">Initializing Cosmic Experience</p>
        </div>

        <div className="loading-visual_1">
          <div className="loading-spinner-container_1">
            <div className="loading-spinner_1">
              <div className="spinner-layer_1 spinner-outer_1"></div>
              <div className="spinner-layer_1 spinner-middle_1"></div>
              <div className="spinner-layer_1 spinner-inner_1"></div>
            </div>
            <p className="loading-spinner-text_1">
              {progress < 30
                ? "Warping space-time..."
                : progress < 70
                ? "Aligning dimensions..."
                : "Finalizing quantum states..."}
            </p>
          </div>

          <div className="loading-progress-container_1">
            <div className="loading-progress-bar_1">
              <div
                className="loading-progress-fill_1"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            <p className="loading-progress-text_1">{progress}%</p>
          </div>
        </div>

        <div className="loading-footer_1">
          <p className="loading-tip_1">
            <span className="tip-icon_1">💡</span> {tips_1[currentTip_1]}
          </p>
        </div>
      </div>

      {showTimeoutPopup && (
        <div className="loading-timeout-overlay_1">
          {/* Main cursor element - placed INSIDE overlay but above content */}
          <div
            className="mouse-trailer_1"
            style={{
              left: `${cursorPosition_1.x}px`,
              top: `${cursorPosition_1.y}px`,
            }}
          ></div>

          {/* Popup Content */}
          <div className="loading-timeout-popup_1">
            <img
              src="https://cdn3.iconfinder.com/data/icons/small-black-v11/512/internet_broken_connection_network_web_connect_global_offline_worldwide_net_disconnected-512.png"
              alt="Broken connection"
              className="timeout-image_1"
            />
            <h3>Cosmic Connection Lost</h3>
            <p>Our quantum servers are struggling to connect...</p>
            <button
              className="reload-button_1"
              onClick={() => window.location.reload()}
              style={{ cursor: "none" }} // Disables default cursor
            >
              REBOOT CONNECTION
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default LoadingScreen;
