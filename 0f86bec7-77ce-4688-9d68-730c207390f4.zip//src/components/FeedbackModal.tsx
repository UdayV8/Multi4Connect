import React, { useState } from "react";
import "@styles/landing.css"; // Make sure to import the CSS

interface FeedbackModalProps {
  type: "bug" | "suggestion";
  onClose: () => void;
  onSubmit: (message: string) => void;
}

const FeedbackModal: React.FC<FeedbackModalProps> = ({
  type,
  onClose,
  onSubmit,
}) => {
  const [message, setMessage] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    setTimeout(() => {
      onSubmit(message);
      setIsSubmitting(false);
      setIsSubmitted(true);
      setTimeout(() => onClose(), 2000);
    }, 1500);
  };

  if (isSubmitted) {
    return (
      <div className="feedback-modal">
        <div className="modal-content">
          <h2>Thank You!</h2>
          <p>
            Your {type === "bug" ? "bug report" : "suggestion"} has been
            received.
          </p>
          <button className="modal-close" onClick={onClose}>
            X
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="feedback-modal">
      <div className="modal-content">
        <button className="modal-close" onClick={onClose}>
          ×
        </button>
        <h2>{type === "bug" ? "Report a Bug" : "Suggest an Idea"}</h2>
        <p className="modal-tagline">
          {type === "bug"
            ? "Help us by reporting any issues you encounter."
            : "Share your ideas to make Multi4Connect better!"}
        </p>
        <p className="reward-notice">
          You'll have a chance to win in-game credits!
        </p>

        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder={
                type === "bug"
                  ? "Please describe the bug and how to reproduce it. Include any error messages you saw."
                  : "Describe your idea in detail. How would it improve the overall in-game experience?"
              }
              required
              rows={6}
            />
          </div>
          <button type="submit" disabled={isSubmitting}>
            {isSubmitting ? "Sending..." : "Submit"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default FeedbackModal; // Make sure this is a default export
