import React, { useState, useEffect } from "react";
import "@styles/gameSelection.css";

type GameSelectionProps = {
  onClose: () => void;
  onStart: (config: {
    playerCount: 4 | 6 | 8;
    gameMode: "single" | "local";
    gameType: "casual" | "ranked";
    teamMode: "ffa" | "teams";
    boardType: "random" | "custom";
    gameOptions: string[];
  }) => void;
};

const GameSelection: React.FC<GameSelectionProps> = ({ onClose, onStart }) => {
  const [selectedMode, setSelectedMode] = useState<
    "single" | "online" | "local"
  >("single");
  const [gameType, setGameType] = useState<"casual" | "ranked">("casual");
  const [teamMode, setTeamMode] = useState<"ffa" | "teams">("ffa");
  const [boardType, setBoardType] = useState<"random" | "custom">("random");
  const [gameOptions, setGameOptions] = useState<string[]>([]);
  const [playerCount, setPlayerCount] = useState<4 | 6 | 8>(4);
  const [cursorPos, setCursorPos] = useState({ x: 0, y: 0 });
  const [trailPos, setTrailPos] = useState({ x: 0, y: 0 });
  const [isHoveringInteractive, setIsHoveringInteractive] = useState(false);
  const [showScrollHint, setShowScrollHint] = useState(true);

  // Global mouse tracking for cursor position
  useEffect(() => {
    const handleGlobalMouseMove = (e: MouseEvent) => {
      setCursorPos({ x: e.clientX, y: e.clientY });
      setTimeout(() => {
        setTrailPos({ x: e.clientX, y: e.clientY });
      }, 100);
    };

    window.addEventListener("mousemove", handleGlobalMouseMove);
    return () => window.removeEventListener("mousemove", handleGlobalMouseMove);
  }, []);

  // Element-specific mouse position tracking for hover effects
  const handleElementMouseMove = (e: React.MouseEvent) => {
    const target = e.currentTarget as HTMLElement;
    const rect = target.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    target.style.setProperty("--mouse-x", `${x}px`);
    target.style.setProperty("--mouse-y", `${y}px`);
  };

  const handleInteractiveEnter = () => {
    setIsHoveringInteractive(true);
  };

  const handleInteractiveLeave = () => {
    setIsHoveringInteractive(false);
  };

  const handleMatchmake = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();

    const config = {
      playerCount,
      gameMode: selectedMode === "online" ? "local" : selectedMode,
      gameType,
      teamMode,
      boardType,
      gameOptions,
    };

    console.log("Starting game with config:", config);
    onStart(config);
  };

  const toggleGameOption = (option: string) => {
    setGameOptions((prev) =>
      prev.includes(option)
        ? prev.filter((o) => o !== option)
        : [...prev, option]
    );
  };

  const OptionCard: React.FC<{
    title: string;
    description: string;
    selected: boolean;
    onClick: () => void;
    comingSoon?: boolean;
  }> = ({ title, description, selected, onClick, comingSoon }) => (
    <div
      className={`option-card ${selected ? "selected" : ""} ${
        comingSoon ? "coming-soon" : ""
      }`}
      onClick={!comingSoon ? onClick : undefined}
      onMouseMove={handleElementMouseMove}
      onMouseEnter={handleInteractiveEnter}
      onMouseLeave={handleInteractiveLeave}
    >
      {comingSoon && <div className="coming-soon-banner">COMING SOON</div>}
      <h4>{title}</h4>
      <p>{description}</p>
    </div>
  );

  const OptionToggle: React.FC<{
    title: string;
    description: string;
    selected: boolean;
    onClick: () => void;
    comingSoon?: boolean;
  }> = ({ title, description, selected, onClick, comingSoon }) => (
    <div
      className={`option-toggle ${selected ? "selected" : ""} ${
        comingSoon ? "coming-soon" : ""
      }`}
      onClick={!comingSoon ? onClick : undefined}
      onMouseMove={handleElementMouseMove}
      onMouseEnter={handleInteractiveEnter}
      onMouseLeave={handleInteractiveLeave}
    >
      {comingSoon && <div className="coming-soon-banner">COMING SOON</div>}
      <div className="toggle-indicator">
        <div className={`toggle-circle ${selected ? "on" : "off"}`} />
      </div>
      <div className="toggle-content">
        <h4>{title}</h4>
        <p>{description}</p>
      </div>
    </div>
  );

  return (
    <div className="game-selection-modal">
      <div
        className={`custom-cursor ${
          isHoveringInteractive ? "interactive" : ""
        }`}
        style={{
          left: `${cursorPos.x}px`,
          top: `${cursorPos.y}px`,
          transform: `translate(-50%, -50%) scale(${
            isHoveringInteractive ? 1.5 : 1
          })`,
        }}
      />
      <div
        className={`cursor-tracer ${
          isHoveringInteractive ? "interactive" : ""
        }`}
        style={{
          left: `${trailPos.x}px`,
          top: `${trailPos.y}px`,
          transform: `translate(-50%, -50%) scale(${
            isHoveringInteractive ? 1.2 : 1
          })`,
        }}
      />
      <div className="modal-backdrop" onClick={onClose}></div>
      {/* Scroll hint positioned outside modal */}
      <div className="scroll-hint-container">
        <div
          className="scroll-hint"
          onMouseEnter={handleInteractiveEnter}
          onMouseLeave={handleInteractiveLeave}
        >
          ⬇️<div className="scroll-hint-text">Scroll to play</div>
        </div>
      </div>
      <div
        className="modal-content"
        onScroll={(e) => {
          const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
          const atBottom = scrollHeight - (scrollTop + clientHeight) < 10;
          setShowScrollHint(!atBottom);
        }}
        ref={(el) => {
          if (el) {
            setShowScrollHint(el.scrollHeight > el.clientHeight);
          }
        }}
      >
        <button
          className="modal-close"
          onClick={onClose}
          onMouseEnter={handleInteractiveEnter}
          onMouseLeave={handleInteractiveLeave}
        >
          ×
        </button>

        <h2 className="modal-title">SELECT GAME MODE</h2>

        <div className="selection-section">
          <h3>1. Select Player Mode</h3>
          <div className="option-grid">
            <OptionCard
              title="Single Player"
              description="Play against AI"
              selected={selectedMode === "single"}
              onClick={() => setSelectedMode("single")}
            />
            <OptionCard
              title="Online Multiplayer"
              description="Play against others"
              selected={selectedMode === "online"}
              comingSoon
            />
            <OptionCard
              title="Local Multiplayer"
              description="Play on same device"
              selected={selectedMode === "local"}
              onClick={() => setSelectedMode("local")}
            />
          </div>
        </div>

        <div className="selection-section">
          <h3>2. Number of Players</h3>
          <div className="player-count-options">
            {[4, 6, 8].map((count) => (
              <div
                key={count}
                className={`player-count-option ${
                  playerCount === count ? "selected" : ""
                }`}
                onClick={() => setPlayerCount(count as 4 | 6 | 8)}
                onMouseMove={handleElementMouseMove}
                onMouseEnter={handleInteractiveEnter}
                onMouseLeave={handleInteractiveLeave}
              >
                <h4>{count} Players</h4>
                <p>
                  {count === 4
                    ? "Standard game size"
                    : count === 6
                    ? "Larger game"
                    : "Maximum players"}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="selection-section">
          <h3>3. Select Game Type</h3>
          <div className="option-grid">
            <OptionCard
              title="Casual"
              description="Just for fun"
              selected={gameType === "casual"}
              onClick={() => setGameType("casual")}
            />
            <OptionCard
              title="Ranked"
              description="Competitive play"
              selected={gameType === "ranked"}
              onClick={() => setGameType("ranked")}
              comingSoon
            />
          </div>
        </div>

        {gameType === "casual" && (
          <div className="selection-section">
            <h3>4. Select Team Mode</h3>
            <div className="option-grid">
              <OptionCard
                title="Free-for-All"
                description="Every player for themselves"
                selected={teamMode === "ffa"}
                onClick={() => setTeamMode("ffa")}
              />
              <OptionCard
                title="Teams"
                description="2v2 or 3v3 matches"
                selected={teamMode === "teams"}
                onClick={() => setTeamMode("teams")}
                comingSoon
              />
            </div>
          </div>
        )}

        {gameType === "casual" && (
          <div className="selection-section">
            <h3>5. Select Board Type</h3>
            <div className="option-grid">
              <OptionCard
                title="Random Board"
                description="Surprise layout"
                selected={boardType === "random"}
                onClick={() => setBoardType("random")}
              />
              <OptionCard
                title="Custom Board"
                description="Choose your layout"
                selected={boardType === "custom"}
                onClick={() => setBoardType("custom")}
                comingSoon
              />
            </div>
          </div>
        )}

        {gameType === "casual" && (
          <div className="selection-section">
            <h3>6. Additional Options</h3>
            <div className="option-grid">
              <OptionToggle
                title="Fog of War"
                description="Hide opponent's pieces"
                selected={gameOptions.includes("fog")}
                onClick={() => toggleGameOption("fog")}
                comingSoon
              />
              <OptionToggle
                title="Time Limit"
                description="Add turn timer"
                selected={gameOptions.includes("timer")}
                onClick={() => toggleGameOption("timer")}
                comingSoon
              />
            </div>
          </div>
        )}

        <button
          className="matchmake-button"
          onClick={handleMatchmake}
          onMouseMove={handleElementMouseMove}
          onMouseEnter={handleInteractiveEnter}
          onMouseLeave={handleInteractiveLeave}
        >
          START GAME
        </button>
      </div>
    </div>
  );
};

export default GameSelection;
