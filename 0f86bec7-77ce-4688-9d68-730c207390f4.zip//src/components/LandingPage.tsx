import React, { useEffect, useRef, useState } from "react";
import FeedbackModal from "@/components/FeedbackModal";
import "@styles/landing.css";
import "@styles/loading.css";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  "https://fxkhjldutbgvhokbwhht.supabase.co",
  "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZ4a2hqbGR1dGJndmhva2J3aGh0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDU3MzI4MTgsImV4cCI6MjA2MTMwODgxOH0.SZH8Z3gly2R-_vd5KV8fVS6Oj7ajH5-bmyOIJadfbZ0"
);

type LandingPageProps = {
  onPlay: () => void;
};

const LandingPage: React.FC<LandingPageProps> = ({ onPlay }) => {
  const contentContainerRef = useRef<HTMLDivElement>(null);
  const [isMuted, setIsMuted] = useState(true);
  const [showUnmuteButton, setShowUnmuteButton] = useState(false);
  const [trail, setTrail] = useState<{ x: number; y: number }[]>([]);
  const [showFeedbackModal, setShowFeedbackModal] = useState<
    "bug" | "suggestion" | null
  >(null);
  const [activeTooltip, setActiveTooltip] = useState<{
    text: string;
    x: number;
    y: number;
  } | null>(null);
  const [feedbackStatus, setFeedbackStatus] = useState<{
    visible: boolean;
    success: boolean;
    message: string;
  }>({ visible: false, success: false, message: "" });

  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [cursorPosition, setCursorPosition] = useState({ x: 0, y: 0 });

  const cloudinaryVideoUrl =
    "https://res.cloudinary.com/dqds3c6jj/video/upload/v1745387665/Multi4Connect_Tutorial_qnmosl.mp4";

  const featureDescriptions = {
    "Teams Mode": "Compete in 2v2 or 3v3 matches with friends",
    "Custom Boards": "Create and play on boards with unique designs",
    "Rating System": "Climb the leaderboards with competitive rankings",
    "Account Login": "Save progress by creating your personal accounts",
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    setCursorPosition({ x: e.clientX, y: e.clientY });
    setTrail((prev) => [...prev.slice(-5), { x: e.clientX, y: e.clientY }]);
  };

  const handleFeatureHover = (e: React.MouseEvent, feature: string) => {
    setActiveTooltip({
      text: featureDescriptions[feature as keyof typeof featureDescriptions],
      x: e.clientX + 15,
      y: e.clientY + 15,
    });
  };

  const handleFeedbackSubmit = async (message: string) => {
    if (!message.trim() || !showFeedbackModal) return;

    // Immediately clear the modal but store the type
    const feedbackType = showFeedbackModal;
    setShowFeedbackModal(null);

    // Reset feedback status to ensure new messages show
    setFeedbackStatus({
      visible: false,
      success: false,
      message: "",
    });

    try {
      const { error } = await supabase.from("Feedback Table").insert([
        {
          type: feedbackType,
          message,
          created_at: new Date().toISOString(),
        },
      ]);

      if (error) throw error;

      // Force show success message
      setFeedbackStatus({
        visible: true,
        success: true,
        message: `Thank you! Your ${feedbackType} was received.`,
      });
    } catch (error) {
      // Force show error message
      setFeedbackStatus({
        visible: true,
        success: false,
        message: `Failed to submit: ${error.message}`,
      });
    }
  };

  useEffect(() => {
    // Auto-scroll trigger (runs once on mount)
    const container = document.querySelector(".landing-container");
    if (container) {
      setTimeout(() => {
        container.scrollTo({ top: container.scrollHeight, behavior: "smooth" });
        setTimeout(
          () => container.scrollTo({ top: 0, behavior: "smooth" }),
          1500
        );
      }, 500);
    }

    // Keep all your existing useEffect logic...
  }, []);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleCanPlay = () => {
      video
        .play()
        .then(() => setShowUnmuteButton(false))
        .catch(() => setShowUnmuteButton(true));
    };

    video.src = cloudinaryVideoUrl;
    video.muted = true;
    video.loop = true;
    video.playsInline = true;
    video.preload = "auto";
    video.addEventListener("canplay", handleCanPlay);
    video.load();

    const handleUserInteraction = () => {
      if (video.paused) video.play().catch(console.log);
      if (showUnmuteButton && videoRef.current) {
        videoRef.current.muted = false;
        setIsMuted(false);
        setShowUnmuteButton(false);
      }
    };

    document.addEventListener("click", handleUserInteraction);
    return () => {
      video.removeEventListener("canplay", handleCanPlay);
      document.removeEventListener("click", handleUserInteraction);
    };
  }, [showUnmuteButton]);

  const floatingElements = [
    ...Array.from({ length: 3 }, (_, i) => ({
      id: `coin-gold-${i}`,
      type: "coin",
      variant: "gold",
      size: 25 + i * 15,
      left: 5 + i * 30,
      top: 10 + i * 20,
      animationDuration: 20 + i * 10,
      opacity: 0.12,
      pulseSpeed: 3 + i,
    })),
    ...Array.from({ length: 2 }, (_, i) => ({
      id: `coin-silver-${i}`,
      type: "coin",
      variant: "silver",
      size: 20 + i * 10,
      left: 60 + i * 20,
      top: 30 + i * 10,
      animationDuration: 25 + i * 5,
      opacity: 0.1,
      pulseSpeed: 4 + i,
    })),
    ...Array.from({ length: 8 }, (_, i) => ({
      id: `star-${i}`,
      type: "star",
      size: 2 + Math.random() * 3,
      left: Math.random() * 100,
      top: Math.random() * 100,
      animationDuration: 2 + Math.random() * 3,
      opacity: 0.3 + Math.random() * 0.4,
      delay: Math.random() * 5,
    })),
  ];

  return (
    <div
      ref={containerRef}
      className="landing-container"
      onMouseMove={handleMouseMove}
      style={{ cursor: "none" }}
    >
      {floatingElements.map((element) => (
        <div
          key={element.id}
          className={`floating-element floating-${element.type} ${
            element.variant || ""
          }`}
          style={{
            left: `${element.left}%`,
            top: `${element.top}%`,
            width: `${element.size}px`,
            height: `${element.size}px`,
            animationDuration: `${element.animationDuration}s`,
            opacity: element.opacity,
            animationDelay: `${element.delay || 0}s`,
            filter: `blur(${element.type === "coin" ? "1px" : "0.5px"})`,
          }}
        />
      ))}

      {trail.map((pos, index) => (
        <div
          key={index}
          className="mouse-trailer"
          style={{
            left: `${pos.x}px`,
            top: `${pos.y}px`,
            opacity: index / trail.length,
            transform: activeTooltip ? "scale(1.5)" : "scale(1)",
          }}
        />
      ))}

      {activeTooltip && (
        <div
          className="feature-tooltip"
          style={{ left: `${activeTooltip.x}px`, top: `${activeTooltip.y}px` }}
        >
          {activeTooltip.text}
        </div>
      )}

      {feedbackStatus.visible && (
        <div
          className={`feedback-notification ${
            feedbackStatus.success ? "success" : "error"
          }`}
        >
          <div className="notification-content">{feedbackStatus.message}</div>
        </div>
      )}

      <div className="header-container">
        <h1 className="game-title">
          <span className="title-part">Multi</span>
          <span className="title-highlight">4</span>
          <span className="title-part">Connect</span>
        </h1>
        <p className="game-tagline">The next gen old school experience</p>
      </div>

      <div className="content-container">
        <div className="side-panel updates-panel">
          <h3 className="panel-title">Upcoming</h3>
          <ul className="features-list">
            {[
              { icon: "⚔️", text: "Teams Mode" },
              { icon: "🎨", text: "Custom Boards" },
              { icon: "🏆", text: "Rating System" },
              { icon: "🔐", text: "Account Login" },
            ].map((item, index) => (
              <li
                key={index}
                className="feature-item"
                onMouseEnter={(e) => handleFeatureHover(e, item.text)}
                onMouseLeave={() => setActiveTooltip(null)}
                style={{ cursor: "none" }}
              >
                <span className="feature-icon">{item.icon}</span>
                <span className="feature-text">{item.text}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="demo-board-container">
          <div className="video-wrapper">
            <video
              ref={videoRef}
              className="tutorial-video"
              playsInline
              loop
              muted={isMuted}
              autoPlay
              preload="auto"
            />
            {showUnmuteButton && (
              <button
                className="unmute-button"
                onClick={() => {
                  if (videoRef.current) {
                    videoRef.current.muted = false;
                    setIsMuted(false);
                    setShowUnmuteButton(false);
                    videoRef.current.play().catch(console.error);
                  }
                }}
              >
                🔈 Enable Sound
              </button>
            )}
          </div>
          <div className="video-dimmer"></div>
        </div>

        <div className="side-panel feedback-panel">
          <div>
            <h3 className="panel-title">Feedback</h3>
            {[
              {
                icon: "🐞",
                text: "Report",
                label: "Found a bug?",
                type: "bug",
              },
              {
                icon: "💡",
                text: "Suggest",
                label: "Have an idea?",
                type: "suggestion",
              },
            ].map((item, index) => (
              <div key={index} className="feedback-section">
                <p className="feedback-text">{item.label}</p>
                <button
                  className="feedback-button"
                  onClick={() => {
                    setShowFeedbackModal(item.type);
                    // Scroll to top when button is clicked in mobile view
                    if (window.innerWidth <= 992) {
                      const container =
                        document.querySelector(".landing-container");
                      if (container) {
                        container.scrollTo({
                          top: 0,
                          behavior: "smooth",
                        });
                      }
                    }
                  }}
                  style={{ cursor: "none" }}
                >
                  <span className="button-icon">{item.icon}</span>
                  <span className="button-text">{item.text}</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="action-buttons">
        <button className="play-button" onClick={onPlay}>
          <span className="button-glow"></span>
          <span className="button-text">PLAY NOW</span>
        </button>
      </div>

      {showFeedbackModal && (
        <FeedbackModal
          type={showFeedbackModal}
          onClose={() => setShowFeedbackModal(null)}
          onSubmit={handleFeedbackSubmit}
        />
      )}
    </div>
  );
};

export default LandingPage;
