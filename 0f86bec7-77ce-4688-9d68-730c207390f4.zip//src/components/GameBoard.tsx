import React, { useState, useEffect, useCallback } from "react";
import { initializeGame, applyGravity } from "@game-logic/board";
import {
  checkWinCondition,
  handleBoardDrop,
  getNextPlayerIndex,
  getFinalLeaderboard,
} from "@game-logic/rules";
import { calculateAIMove } from "@game-logic/ai/minimax";
import "@styles/game.css";
import { throttle } from "lodash";

type CellState = {
  type: "empty" | "occupied" | "blocked";
  playable: boolean;
  playerId?: number;
};

type Player = {
  id: number;
  color: string;
  isAI: boolean;
  isActive: boolean;
  hasWon: boolean;
  connect3s: number;
  points: number;
};

type GameState = {
  board: CellState[][];
  players: Player[];
  currentPlayerIndex: number;
  gamePhase: "playing" | "finished";
  dropCount: number;
  winners: number[];
  moveHistory: { playerId: number; col: number; row: number; round: number }[];
};

type GameConfig = {
  playerCount: 4 | 6 | 8;
  gameMode: "single" | "local";
  gameType: "casual" | "ranked";
  teamMode: "ffa" | "teams";
  boardType: "random" | "custom";
  gameOptions: string[];
};

interface GameBoardProps {
  config: GameConfig;
  onExit: () => void;
}

const GameBoard: React.FC<GameBoardProps> = ({ config, onExit }) => {
  const [gameState, setGameState] = useState<GameState>(() => {
    const initialState = initializeGame({
      playerCount: config.playerCount,
      isSinglePlayer: config.gameMode === "single",
      useTeams: config.teamMode === "teams",
      boardType: config.boardType,
    });
    return {
      ...initialState,
      players: initialState.players || [
        {
          id: 1,
          color: "#FF0000",
          isAI: false,
          isActive: true,
          hasWon: false,
          connect3s: 0,
          points: 0,
        },
      ],
      dropCount: initialState.dropCount || 0,
    };
  });

  const [isAnimating, setIsAnimating] = useState(false);
  const [isDropping, setIsDropping] = useState(false);
  const [winningCells, setWinningCells] = useState<Set<string>>(new Set());
  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [leaderboard, setLeaderboard] = useState<Player[]>([]);
  const [lastMove, setLastMove] = useState<{ row: number; col: number } | null>(
    null
  );

  const currentPlayer = gameState.players[gameState.currentPlayerIndex] || {
    id: 1,
    color: "#FF0000",
    isAI: false,
    isActive: true,
    hasWon: false,
    connect3s: 0,
    points: 0,
  };

  const countConnect3s = useCallback(
    (board: CellState[][], playerId: number): number => {
      if (!lastMove) return 0;

      const { row, col } = lastMove;
      const size = board.length;
      let count = 0;

      if (
        board[row][col].type !== "occupied" ||
        board[row][col].playerId !== playerId
      ) {
        return 0;
      }

      const directions = [
        { dr: 0, dc: 1 },
        { dr: 1, dc: 0 },
        { dr: 1, dc: 1 },
        { dr: 1, dc: -1 },
      ];

      for (const { dr, dc } of directions) {
        let lineLength = 1;

        for (let i = 1; i < 3; i++) {
          const newRow = row + i * dr;
          const newCol = col + i * dc;
          if (
            newRow >= 0 &&
            newRow < size &&
            newCol >= 0 &&
            newCol < size &&
            board[newRow][newCol].type === "occupied" &&
            board[newRow][newCol].playerId === playerId
          ) {
            lineLength++;
          } else {
            break;
          }
        }

        for (let i = 1; i < 3; i++) {
          const newRow = row - i * dr;
          const newCol = col - i * dc;
          if (
            newRow >= 0 &&
            newRow < size &&
            newCol >= 0 &&
            newCol < size &&
            board[newRow][newCol].type === "occupied" &&
            board[newRow][newCol].playerId === playerId
          ) {
            lineLength++;
          } else {
            break;
          }
        }

        if (lineLength >= 3) {
          count++;
        }
      }

      return count;
    },
    [lastMove]
  );

  const isBoardFull = (board: CellState[][]): boolean => {
    return board.every((row) =>
      row.every((cell) => !cell.playable || cell.type !== "empty")
    );
  };

  const findFirstValidMove = (board: CellState[][]): number => {
    for (let col = 0; col < board[0].length; col++) {
      for (let row = board.length - 1; row >= 0; row--) {
        if (board[row][col].playable && board[row][col].type === "empty") {
          return col;
        }
      }
    }
    return -1;
  };

  const makeMove = useCallback(
    (col: number) => {
      if (gameState.gamePhase === "finished" || isAnimating || isDropping)
        return;

      const { row, changed } = applyGravity(gameState.board, col);
      if (!changed || row === -1) return;

      setIsAnimating(true);
      const newBoard = gameState.board.map((r) => [...r]);
      newBoard[row][col] = {
        type: "occupied",
        playerId: currentPlayer.id,
        playable: true,
      };

      const winCheck = checkWinCondition(newBoard, row, col);
      const newWinners = winCheck
        ? [...gameState.winners, currentPlayer.id]
        : [...gameState.winners];

      setLastMove({ row, col });

      const playersWithUpdated3s = gameState.players.map((player) => {
        const new3s = countConnect3s(newBoard, player.id);
        return {
          ...player,
          connect3s: player.connect3s + new3s,
          points:
            player.points +
            new3s * 5 +
            (winCheck && player.id === currentPlayer.id ? 100 : 0),
        };
      });

      const currentRound =
        Math.floor(gameState.moveHistory.length / gameState.players.length) + 1;

      setGameState((prev) => {
        // First create the updated state with the current move
        const updatedState = {
          ...prev,
          board: newBoard,
          moveHistory: [
            ...prev.moveHistory,
            { playerId: currentPlayer.id, col, row, round: currentRound },
          ],
          winners: newWinners,
          players: playersWithUpdated3s.map((p) => ({
            ...p,
            hasWon: newWinners.includes(p.id),
          })),
          // Don't update currentPlayerIndex yet - we'll handle it after drop if needed
          gamePhase:
            newWinners.length >= config.playerCount - 1
              ? "finished"
              : "playing",
        };

        if (updatedState.gamePhase === "finished") {
          const finalPlayers = updatedState.players.map((player) => ({
            ...player,
            points:
              player.points + (player.hasWon ? 100 : 0) + player.connect3s * 5,
          }));
          setLeaderboard(getFinalLeaderboard(finalPlayers));
          setShowLeaderboard(true);
          return updatedState;
        }

        // Check if we need to drop the board
        const shouldDrop = handleBoardDrop(updatedState);
        if (shouldDrop.droppedBoard) {
          setIsDropping(true);
          setTimeout(() => {
            setGameState((prev) => {
              const droppedState = shouldDrop.newState;
              setIsDropping(false);

              if (droppedState.dropCount >= 4) {
                const finalPlayers = droppedState.players.map((player) => ({
                  ...player,
                  points:
                    player.points +
                    (player.hasWon ? 100 : 0) +
                    player.connect3s * 5,
                }));
                setLeaderboard(getFinalLeaderboard(finalPlayers));
                setShowLeaderboard(true);
                return { ...droppedState, gamePhase: "finished" };
              }
              return droppedState;
            });
          }, 1000);

          // Return the state with the current player's move but don't change turn yet
          return updatedState;
        }

        // If no drop happened, proceed to next player
        return {
          ...updatedState,
          currentPlayerIndex: getNextPlayerIndex(updatedState),
        };
      });

      setTimeout(() => {
        setWinningCells(
          winCheck
            ? new Set(winCheck.cells.map((c) => `${c.row},${c.col}`))
            : new Set()
        );
        setIsAnimating(false);
      }, 300);
    },
    [
      gameState,
      currentPlayer.id,
      isAnimating,
      isDropping,
      countConnect3s,
      config.playerCount,
    ]
  );

  useEffect(() => {
    if (
      !isAnimating &&
      !isDropping &&
      currentPlayer.isAI &&
      gameState.gamePhase === "playing"
    ) {
      const throttledAIMove = throttle(() => {
        const calculateMove = () => {
          const startTime = performance.now();
          const aiDepth =
            config.gameType === "ranked"
              ? gameState.dropCount > 1
                ? 4
                : 3
              : gameState.dropCount > 1
              ? 2
              : 1;

          const aiMove = calculateAIMove(gameState, aiDepth);

          if (performance.now() - startTime < 300) {
            makeMove(aiMove);
          } else {
            const fallbackMove = findFirstValidMove(gameState.board);
            if (fallbackMove !== -1) {
              makeMove(fallbackMove);
            }
          }
        };

        setTimeout(calculateMove, 0);
      }, 300);

      const delay = currentPlayer.id === 1 ? 400 : 600;
      const timer = setTimeout(throttledAIMove, delay);

      return () => {
        clearTimeout(timer);
        throttledAIMove.cancel();
      };
    }
  }, [
    gameState,
    isAnimating,
    isDropping,
    makeMove,
    config.gameType,
    currentPlayer,
  ]);

  useEffect(() => {
    if (gameState.gamePhase === "finished" && !showLeaderboard) {
      const finalPlayers = gameState.players.map((player) => ({
        ...player,
        points: (player.points || 0) + (player.hasWon ? 100 : 0),
      }));
      setLeaderboard(getFinalLeaderboard(finalPlayers));
      setShowLeaderboard(true);
    }
  }, [gameState.gamePhase, showLeaderboard]);

  // Replace your current cursor useEffect with this:
  // Replace your cursor useEffect with this:
  useEffect(() => {
    const trailer = document.getElementById("cursor-trailer");
    if (!trailer) return;

    const moveCursor = (e: MouseEvent) => {
      const x = e.clientX;
      const y = e.clientY;

      trailer.style.left = `${x}px`;
      trailer.style.top = `${y}px`;

      // Toggle large class when hovering over cells
      if ((e.target as HTMLElement)?.classList.contains("cell")) {
        trailer.classList.add("large");
      } else {
        trailer.classList.remove("large");
      }
    };

    window.addEventListener("mousemove", moveCursor);

    return () => {
      window.removeEventListener("mousemove", moveCursor);
    };
  }, []);

  // Keep your original cursor element in JSX:
  <div id="cursor-trailer" className="cursor-trailer"></div>;

  return (
    <div className="game-container">
      <div className="cosmic-bg">
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="star"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              opacity: Math.random() * 0.7 + 0.3,
              transform: `scale(${Math.random() * 0.5 + 0.5})`,
            }}
          />
        ))}
      </div>
      <div id="cursor-trailer" className="cursor-trailer"></div>

      <div className="game-layout">
        <header className="game-header">
          <h1 className="game-title">Multi4Connect</h1>
          <div className="game-info">
            <h2 className="neon-text">
              {config.playerCount}-Player{" "}
              {config.gameMode === "single" ? "vs AI" : "Local"}
            </h2>
            <div className="current-turn">
              <span>Current: </span>
              <span
                className="player-indicator"
                style={{
                  color: currentPlayer.color,
                  textShadow: `0 0 10px ${currentPlayer.color}`,
                }}
              >
                Player {currentPlayer.id} {currentPlayer.isAI ? "(AI)" : ""}
              </span>
            </div>
          </div>
          <div className="game-controls">
            {isDropping && (
              <div className="drop-notification">
                <span className="drop-text">Board Dropping!</span>
                <span className="drop-pulse"></span>
              </div>
            )}
            <div className="drop-counter">
              <span className="counter-icon">⬇️</span>
              <span>Drops: {Math.min(gameState.dropCount, 3)}/3</span>
            </div>
            <button className="exit-btn" onClick={onExit}>
              <span className="btn-content">Exit Game</span>
              <span className="btn-glow"></span>
            </button>
          </div>
        </header>

        <main className="game-main">
          <aside className="left-panel">
            <div className="panel-glow"></div>
            <div className="player-stats">
              <h3 className="panel-title">
                <span className="title-text">Players</span>
                <span className="title-underline"></span>
              </h3>
              {gameState.players.map((player) => (
                <div
                  key={player.id}
                  className={`player-stat ${
                    player.id === currentPlayer.id ? "active" : ""
                  } ${player.hasWon ? "winner" : ""}`}
                  style={
                    {
                      "--player-color": player.color,
                      borderLeft: `3px solid ${player.color}`,
                    } as React.CSSProperties
                  }
                >
                  <div className="player-glow"></div>
                  <span className="player-name">
                    <span
                      className="player-icon"
                      style={{ backgroundColor: player.color }}
                    />
                    <span className="player-id">Player {player.id}</span>
                    {player.isAI && <span className="ai-tag">AI</span>}
                  </span>
                  <div className="player-stats-right">
                    <span className="connect3-count">
                      <span className="stat-icon">🔹</span>
                      {player.connect3s}
                    </span>
                    {player.hasWon && (
                      <span className="winner-badge">
                        <span className="trophy-icon">🏆</span>
                        WINNER
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </aside>

          <div className="board-section">
            <div className="column-labels">
              {gameState.board[0]?.map((_, col) => (
                <div
                  key={`col-${col}`}
                  className="column-label"
                  style={{ color: currentPlayer.color }}
                >
                  {String.fromCharCode(65 + col)}
                </div>
              ))}
            </div>

            <div className="board-container">
              <div className="row-labels">
                {gameState.board.map((_, rowIndex) => (
                  <div
                    key={`row-label-${rowIndex}`}
                    className="row-label"
                    style={{ color: currentPlayer.color }}
                  >
                    {rowIndex + 1}
                  </div>
                ))}
              </div>

              <div className={`board ${isDropping ? "dropping" : ""}`}>
                {gameState.board.map((row, rowIndex) => (
                  <div key={`row-${rowIndex}`} className="board-row">
                    {row.map((cell, colIndex) => {
                      const isWinning = winningCells.has(
                        `${rowIndex},${colIndex}`
                      );
                      const isLastMove =
                        lastMove?.row === rowIndex &&
                        lastMove?.col === colIndex;
                      const playerColor =
                        cell.type === "occupied"
                          ? gameState.players.find(
                              (p) => p.id === cell.playerId
                            )?.color
                          : "transparent";

                      return (
                        <div
                          key={`cell-${rowIndex}-${colIndex}`}
                          className={`cell ${!cell.playable ? "blocked" : ""} ${
                            isWinning ? "winning" : ""
                          } ${isLastMove ? "last-move" : ""}`}
                          onClick={() =>
                            !currentPlayer.isAI && makeMove(colIndex)
                          }
                          style={
                            {
                              "--player-color": playerColor,
                              "--current-color": currentPlayer.color,
                            } as React.CSSProperties
                          }
                        >
                          {cell.type === "occupied" && (
                            <>
                              <div className="piece" />
                              {isWinning && (
                                <div className="winning-pulse"></div>
                              )}
                              {isLastMove && (
                                <div className="last-move-ring"></div>
                              )}
                            </>
                          )}
                          {!cell.playable && (
                            <div className="blocked-pattern"></div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>

          <aside className="right-panel">
            <div className="panel-glow"></div>
            <div className="move-history">
              <h3 className="panel-title">
                <span className="title-text">Moves</span>
                <span className="title-underline"></span>
              </h3>
              <div className="moves-container">
                {gameState.moveHistory.slice(-10).map((move, i) => {
                  const player = gameState.players.find(
                    (p) => p.id === move.playerId
                  );
                  const isLast = i === gameState.moveHistory.length - 1;

                  return (
                    <div
                      key={i}
                      className={`move ${isLast ? "last-move-history" : ""}`}
                      style={
                        {
                          "--player-color": player?.color,
                        } as React.CSSProperties
                      }
                    >
                      <div className="move-glow"></div>
                      <span className="move-coord">
                        {String.fromCharCode(65 + move.col)}
                        {move.row + 1}
                      </span>
                      <span className="move-player">P{move.playerId}</span>
                      {isLast && <div className="move-pulse"></div>}
                    </div>
                  );
                })}
              </div>
            </div>
          </aside>
        </main>
      </div>

      {showLeaderboard && (
        <div className="leaderboard-modal">
          <div className="leaderboard-content">
            <div className="leaderboard-glow"></div>
            <h2 className="neon-text">
              <span className="title-main">Game Finished!</span>
              <span className="title-sub">Final Results</span>
            </h2>
            <div className="leaderboard">
              {leaderboard.map((player, index) => (
                <div
                  key={player.id}
                  className={`leaderboard-entry ${
                    player.hasWon ? "winner" : ""
                  }`}
                  style={
                    { "--player-color": player.color } as React.CSSProperties
                  }
                >
                  <div className="entry-glow"></div>
                  <span className="position">{index + 1}.</span>
                  <span className="player-info">
                    <span
                      className="player-color"
                      style={{ backgroundColor: player.color }}
                    />
                    <span className="player-name">
                      Player {player.id}
                      {player.isAI && <span className="ai-tag">AI</span>}
                    </span>
                  </span>
                  <span className="stats">
                    {player.hasWon && (
                      <span className="winner">
                        <span className="trophy-icon">🏆</span>
                        WINNER
                      </span>
                    )}
                    <span className="connect3s">
                      <span className="stat-icon">🔹</span>
                      {player.connect3s} 3's
                    </span>
                    <span className="points">
                      <span className="stat-icon">⭐</span>
                      {player.points} pts
                    </span>
                  </span>
                </div>
              ))}
            </div>
            <button
              className="exit-btn"
              onClick={() => {
                setShowLeaderboard(false);
                onExit();
              }}
            >
              <span className="btn-content">Exit Game</span>
              <span className="btn-glow"></span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default GameBoard;
