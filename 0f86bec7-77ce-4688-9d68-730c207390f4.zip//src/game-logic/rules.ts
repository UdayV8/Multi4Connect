import {
  GameState,
  Player,
  PlayerID,
  CellState,
  WinCondition,
  GameActionResult,
} from "@types/game";
import { dropBottomRows, createNewRows, applyGravity } from "@game-logic/board";

export const checkWinCondition = (
  board: CellState[][],
  lastRow: number,
  lastCol: number
): WinCondition | null => {
  const playerId = (
    board[lastRow][lastCol] as { type: "occupied"; playerId: PlayerID }
  ).playerId;
  const directions = [
    { dr: 0, dc: 1, name: "horizontal" }, // Horizontal
    { dr: 1, dc: 0, name: "vertical" }, // Vertical
    { dr: 1, dc: 1, name: "diagonal" }, // Diagonal down-right
    { dr: 1, dc: -1, name: "diagonal" }, // Diagonal down-left
  ];

  for (const { dr, dc, name } of directions) {
    const line = checkDirection(board, lastRow, lastCol, dr, dc, playerId);
    if (line.length >= 4) {
      return { type: name, cells: line };
    }
  }

  return null;
};

function checkDirection(
  board: CellState[][],
  row: number,
  col: number,
  dr: number,
  dc: number,
  playerId: PlayerID
): { row: number; col: number }[] {
  const line = [{ row, col }];

  // Check in positive direction
  for (let i = 1; i < 4; i++) {
    const newRow = row + i * dr;
    const newCol = col + i * dc;
    if (!isValidCell(board, newRow, newCol, playerId)) break;
    line.push({ row: newRow, col: newCol });
  }

  // Check in negative direction
  for (let i = 1; i < 4; i++) {
    const newRow = row - i * dr;
    const newCol = col - i * dc;
    if (!isValidCell(board, newRow, newCol, playerId)) break;
    line.push({ row: newRow, col: newCol });
  }

  return line;
}

function isValidCell(
  board: CellState[][],
  row: number,
  col: number,
  playerId: PlayerID
): boolean {
  return (
    row >= 0 &&
    row < board.length &&
    col >= 0 &&
    col < board[0].length &&
    board[row][col].type === "occupied" &&
    board[row][col].playerId === playerId
  );
}

export const getNextPlayerIndex = (state: GameState): number => {
  let nextIndex = (state.currentPlayerIndex + 1) % state.players.length;
  let attempts = 0;

  while (attempts < state.players.length) {
    if (state.players[nextIndex].isActive && !state.players[nextIndex].hasWon) {
      return nextIndex;
    }
    nextIndex = (nextIndex + 1) % state.players.length;
    attempts++;
  }

  return state.currentPlayerIndex; // Fallback if all players won
};

export const shouldDropBoard = (state: GameState): boolean => {
  if (state.dropCount >= 4) return false;

  // Check if board is full (excluding blocked cells)
  const isFull = state.board.every((row) =>
    row.every((cell) => !cell.playable || cell.type !== "empty")
  );

  return isFull && state.winners.length < state.players.length - 1;
};

export const handleBoardDrop = (state: GameState): GameActionResult => {
  // Maximum 3 drops allowed
  if (state.dropCount >= 4 || state.gamePhase === "finished") {
    return { newState: state, droppedBoard: false };
  }

  const isBoardFull = state.board.every((row) =>
    row.every((cell) => !cell.playable || cell.type !== "empty")
  );

  if (!isBoardFull) return { newState: state, droppedBoard: false };

  const newBoard = dropBottomRows([...state.board]);
  newBoard.unshift(...createNewRows(state.board[0].length as BoardSize));

  const newDropCount = state.dropCount + 1;

  // Get the next player index based on the current state
  const nextPlayerIndex = getNextPlayerIndex(state);

  return {
    newState: {
      ...state,
      board: newBoard,
      dropCount: newDropCount,
      currentPlayerIndex: nextPlayerIndex, // Use the calculated next player
      gamePhase: newDropCount >= 4 ? "finished" : "playing",
    },
    droppedBoard: true,
  };
};

export const shouldEndGame = (state: GameState): boolean => {
  // Game ends when:
  // 1. Max board drops reached (3) AND board is full
  // 2. All but one player has connected 4
  // 3. Board is completely full (handled elsewhere)
  return (
    (state.dropCount >= 4 &&
      state.board.every((row) =>
        row.every((cell) => !cell.playable || cell.type !== "empty")
      )) ||
    state.winners.length >= state.players.length - 1
  );
};

export const getFinalLeaderboard = (players: Player[]): Player[] => {
  return [...players]
    .sort((a, b) => {
      // First sort by who has won
      if (a.hasWon !== b.hasWon) return b.hasWon ? 1 : -1;
      // Then by connect3s count (descending)
      if (b.connect3s !== a.connect3s) return b.connect3s - a.connect3s;
      // Finally by points (descending)
      return b.points - a.points;
    })
    .map((player, index) => ({
      ...player,
      position: index + 1,
    }));
};

const calculatePoints = (position: number, connect3s: number) => {
  // Customize your points system here
  const positionPoints = [100, 75, 50, 40, 30, 20, 10, 5][position - 1] || 0;
  return positionPoints + connect3s * 5;
};

function countConnect3s(board: CellState[][], playerId: PlayerID): number {
  // Similar to win checking but for 3-in-a-row
  let count = 0;

  for (let row = 0; row < board.length; row++) {
    for (let col = 0; col < board[row].length; col++) {
      if (
        board[row][col].type === "occupied" &&
        board[row][col].playerId === playerId
      ) {
        if (checkConnect3(board, row, col)) count++;
      }
    }
  }

  return count;
}

function checkConnect3(
  board: CellState[][],
  row: number,
  col: number
): boolean {
  // Implementation similar to checkWinCondition but for 3-in-a-row
  // (Omitted for brevity - would check all directions for length 3)
  return false;
}

export const updatePlayers = (
  players: Player[],
  playerId: PlayerID,
  winCheck: WinCondition | null
): Player[] => {
  return players.map((player) => {
    if (player.id !== playerId) return player;

    return {
      ...player,
      hasWon: winCheck !== null,
      winsAtMove: winCheck
        ? player.winsAtMove || Date.now()
        : player.winsAtMove,
    };
  });
};
