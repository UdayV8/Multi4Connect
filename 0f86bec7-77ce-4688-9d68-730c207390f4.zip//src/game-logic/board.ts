import { GameState, Player, PlayerID, CellState, BoardSize } from "@types/game";

// Updated colors with better contrast
const PLAYER_COLORS = [
  "#FF0000", // Bright Red
  "#00FF00", // Bright Green
  "#0000FF", // Bright Blue
  "#FFFF00", // Yellow
  "#FF00FF", // Magenta
  "#00FFFF", // Cyan
  "#FF8000", // Orange
  "#8000FF", // Purple
];

const TEAM_COLORS = ["#FF0000", "#0000FF"]; // Red vs Blue (high contrast)

export function initializeGame(config: {
  playerCount: 4 | 6 | 8;
  isSinglePlayer: boolean;
  useTeams?: boolean;
  boardType: "random" | "custom";
}): GameState {
  const boardSize = getBoardSize(config.playerCount);
  const players = initializePlayers(config);

  // Validate players were created
  if (!players || players.length === 0) {
    throw new Error("Failed to initialize players");
  }

  return {
    board: generateBoard(boardSize, config.boardType),
    players,
    currentPlayerIndex: 0,
    gamePhase: "playing",
    dropCount: 0,
    winners: [],
    moveHistory: [],
  };
}

function getBoardSize(playerCount: 4 | 6 | 8): BoardSize {
  switch (playerCount) {
    case 4:
      return 10;
    case 6:
      return 12;
    case 8:
      return 14;
    default:
      throw new Error(`Invalid player count: ${playerCount}`);
  }
}

function initializePlayers(config: {
  playerCount: 4 | 6 | 8;
  isSinglePlayer: boolean;
  useTeams?: boolean;
}): Player[] {
  const colors = config.useTeams ? TEAM_COLORS : PLAYER_COLORS;

  return Array.from({ length: config.playerCount }, (_, i) => {
    const playerId = (i + 1) as PlayerID;
    return {
      id: playerId,
      color: config.useTeams
        ? colors[i % 2]
        : PLAYER_COLORS[i % PLAYER_COLORS.length],
      isAI: config.isSinglePlayer && i > 0,
      isActive: true,
      hasWon: false,
      connect3s: 0,
      winsAtMove: undefined,
      points: 0, // Added missing points field
    };
  });
}

export function generateBoard(
  size: BoardSize,
  type: "random" | "custom"
): CellState[][] {
  const board: CellState[][] = [];
  const totalCells = size * size;
  const unplayableCount = Math.floor(totalCells * 0.2);

  if (type === "custom") {
    // Initialize empty playable board for custom
    for (let row = 0; row < size; row++) {
      const rowCells: CellState[] = [];
      for (let col = 0; col < size; col++) {
        rowCells.push({ type: "empty", playable: true });
      }
      board.push(rowCells);
    }
    return board;
  }

  // Generate random board
  const unplayablePositions = new Set<string>();
  while (unplayablePositions.size < unplayableCount) {
    const row = Math.floor(Math.random() * size);
    const col = Math.floor(Math.random() * size);
    unplayablePositions.add(`${row},${col}`);
  }

  // Build the board
  for (let row = 0; row < size; row++) {
    const rowCells: CellState[] = [];
    for (let col = 0; col < size; col++) {
      const isUnplayable = unplayablePositions.has(`${row},${col}`);
      rowCells.push(
        isUnplayable
          ? { type: "blocked", playable: false }
          : { type: "empty", playable: true }
      );
    }
    board.push(rowCells);
  }

  return board;
}

export function createNewRows(
  width: BoardSize,
  count: number = 3
): CellState[][] {
  const newRows: CellState[][] = [];
  const cellsPerRow = width;
  const unplayablePerRow = Math.floor(cellsPerRow * 0.2);

  for (let i = 0; i < count; i++) {
    const row: CellState[] = Array(cellsPerRow)
      .fill(null)
      .map(() => ({ type: "empty", playable: true }));

    // Add unplayable cells
    let unplayableAdded = 0;
    const unplayableIndices = new Set<number>();
    while (unplayableAdded < unplayablePerRow) {
      const randomCol = Math.floor(Math.random() * cellsPerRow);
      if (!unplayableIndices.has(randomCol)) {
        row[randomCol] = { type: "blocked", playable: false };
        unplayableIndices.add(randomCol);
        unplayableAdded++;
      }
    }

    newRows.push(row);
  }

  return newRows;
}

export function applyGravity(
  board: CellState[][],
  col: number
): { row: number; changed: boolean } {
  if (!board || board.length === 0) {
    return { row: -1, changed: false };
  }

  for (let row = board.length - 1; row >= 0; row--) {
    if (row >= board.length || col >= board[row].length) {
      continue; // Skip invalid positions
    }

    const cell = board[row][col];
    if (cell?.playable && cell?.type === "empty") {
      return {
        row: Math.max(0, Math.min(row, board.length - 1)),
        changed: true,
      };
    }
  }
  return { row: -1, changed: false };
}

export function dropBottomRows(
  board: CellState[][],
  rowsToDrop: number = 3
): CellState[][] {
  if (!board || board.length <= rowsToDrop) {
    return board; // Return original if invalid
  }

  // Remove bottom rows
  const newBoard = board.slice(0, -rowsToDrop);

  // Apply gravity to remaining pieces
  for (let col = 0; col < newBoard[0].length; col++) {
    for (let row = newBoard.length - 1; row >= 0; row--) {
      if (
        row < newBoard.length &&
        col < newBoard[row].length &&
        newBoard[row][col]?.type === "occupied"
      ) {
        const playerId = newBoard[row][col].playerId;
        const { row: landingRow } = applyGravity(newBoard, col);

        if (
          landingRow >= 0 &&
          landingRow < newBoard.length &&
          landingRow !== row
        ) {
          newBoard[landingRow][col] = {
            type: "occupied",
            playerId,
            playable: true,
          };
          newBoard[row][col] = { type: "empty", playable: true };
        }
      }
    }
  }

  return newBoard;
}
