import { GameState, PlayerID, CellState } from "@types/game";

const WIN_SCORE = 100000;
const CONNECT3_SCORE = 5000;
const CONNECT2_SCORE = 200;
const CENTER_BONUS = 30;
const EDGE_PENALTY = -10;

export function evaluateBoard(state: GameState, aiPlayerId: PlayerID): number {
  let score = 0;
  const size = state.board.length;
  const centerCol = Math.floor(size / 2);

  // Check all possible 4-cell segments
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (col <= size - 4) {
        // Horizontal segments
        score += evaluateSegment(state.board, row, col, 0, 1, aiPlayerId);
      }
      if (row <= size - 4) {
        // Vertical segments
        score += evaluateSegment(state.board, row, col, 1, 0, aiPlayerId);
      }
      if (row <= size - 4 && col <= size - 4) {
        // Diagonal down-right
        score += evaluateSegment(state.board, row, col, 1, 1, aiPlayerId);
      }
      if (row <= size - 4 && col >= 3) {
        // Diagonal down-left
        score += evaluateSegment(state.board, row, col, 1, -1, aiPlayerId);
      }

      // Positional evaluation
      if (state.board[row][col].type === "occupied") {
        score += evaluateCellPosition(
          row,
          col,
          size,
          centerCol,
          state.board[row][col].playerId === aiPlayerId
        );
      }
    }
  }

  // Dynamic weights based on game phase
  const gamePhaseWeight = calculateGamePhaseWeight(state);
  score *= gamePhaseWeight;

  // Consider connect3 counts for tiebreaker situations
  const aiPlayer = state.players.find((p) => p.id === aiPlayerId);
  if (aiPlayer) {
    score += aiPlayer.connect3s * CONNECT3_SCORE;
  }

  return score;
}

function evaluateSegment(
  board: CellState[][],
  startRow: number,
  startCol: number,
  rowStep: number,
  colStep: number,
  aiPlayerId: PlayerID
): number {
  let aiCount = 0;
  let opponentCount = 0;
  let emptyCells = 0;
  const size = board.length;

  for (let i = 0; i < 4; i++) {
    const row = startRow + i * rowStep;
    const col = startCol + i * colStep;

    // Skip if out of bounds or blocked cell
    if (
      row < 0 ||
      row >= size ||
      col < 0 ||
      col >= size ||
      !board[row][col].playable
    ) {
      return 0;
    }

    const cell = board[row][col];
    if (cell.type === "occupied") {
      if (cell.playerId === aiPlayerId) {
        aiCount++;
      } else {
        opponentCount++;
      }
    } else {
      emptyCells++;
    }
  }

  // Early return if both players have pieces in the segment
  if (aiCount > 0 && opponentCount > 0) {
    return 0;
  }

  // Evaluate potential segments
  if (aiCount === 4) return WIN_SCORE;
  if (opponentCount === 4) return -WIN_SCORE;
  if (opponentCount === 3 && emptyCells === 1) return -8000;
  if (aiCount === 3 && emptyCells === 1) return 5000;
  if (opponentCount === 2 && emptyCells === 2) return -100;
  if (aiCount === 2 && emptyCells === 2) return 50;

  return 0;
}

function evaluateCellPosition(
  row: number,
  col: number,
  size: number,
  centerCol: number,
  isAI: boolean
): number {
  let score = 0;

  // Center preference
  const colDistance = Math.abs(col - centerCol);
  const centerWeight = (size / 2 - colDistance) * 5;
  score += isAI ? centerWeight : -centerWeight;

  // Edge penalty
  if (col === 0 || col === size - 1 || row === size - 1) {
    score += isAI ? EDGE_PENALTY : -EDGE_PENALTY;
  }

  return score;
}

function calculateGamePhaseWeight(state: GameState): number {
  const totalCells = state.board.length * state.board[0].length;
  let filledCells = 0;

  // Count filled cells
  for (const row of state.board) {
    for (const cell of row) {
      if (cell.type === "occupied") filledCells++;
    }
  }

  const fillRatio = filledCells / totalCells;

  // Early game - more positional play
  if (fillRatio < 0.3) return 0.8;
  // Mid game - balanced
  if (fillRatio < 0.7) return 1.0;
  // End game - more aggressive
  return 1.5;
}

export function evaluatePlayerProgress(
  state: GameState,
  playerId: PlayerID
): number {
  let score = 0;
  const size = state.board.length;

  // Count potential winning paths
  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (
        state.board[row][col].type === "occupied" &&
        state.board[row][col].playerId === playerId
      ) {
        // Check all directions
        const directions = [
          { dr: 0, dc: 1 },
          { dr: 1, dc: 0 },
          { dr: 1, dc: 1 },
          { dr: 1, dc: -1 },
        ];

        for (const { dr, dc } of directions) {
          const segment = checkPotentialWin(
            state.board,
            row,
            col,
            dr,
            dc,
            playerId
          );
          if (segment.potential > 0) {
            score += segment.potential * 10;
          }
        }
      }
    }
  }

  return score;
}

function checkPotentialWin(
  board: CellState[][],
  row: number,
  col: number,
  dr: number,
  dc: number,
  playerId: PlayerID
): { potential: number; blocked: boolean } {
  let potential = 0;
  let blocked = false;
  const size = board.length;

  for (let i = 1; i < 4; i++) {
    const newRow = row + i * dr;
    const newCol = col + i * dc;

    if (newRow < 0 || newRow >= size || newCol < 0 || newCol >= size) {
      blocked = true;
      break;
    }

    const cell = board[newRow][newCol];
    if (!cell.playable) {
      blocked = true;
      break;
    }

    if (cell.type === "occupied") {
      if (cell.playerId !== playerId) {
        blocked = true;
        break;
      }
    } else {
      potential++;
    }
  }

  return { potential, blocked };
}
