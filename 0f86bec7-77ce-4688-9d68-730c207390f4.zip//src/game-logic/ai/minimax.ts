import { GameState, PlayerID, MinimaxParams } from "@types/game";
import { checkWinCondition, getNextPlayerIndex } from "@game-logic/rules";
import { applyGravity } from "@game-logic/board";
import { cloneDeep } from "lodash";

// Scoring constants
const WIN_SCORE = 1000000;
const LOSS_SCORE = -1000000;
const CONNECT3_SCORE = 50000;
const CONNECT2_SCORE = 2000;
const CENTER_COLUMN_BONUS = 100;
const EDGE_PENALTY = -50;
const MOBILITY_FACTOR = 50;
const THREAT_MULTIPLIER = 10;
const DROP_POTENTIAL_MULTIPLIER = 30;

export const calculateAIMove = (
  state: GameState,
  depth: number = 5
): number => {
  const validColumns = getValidColumns(state.board);
  if (validColumns.length === 0) return 0;

  const aiPlayerId = state.players[state.currentPlayerIndex].id;
  let bestScore = -Infinity;
  let bestColumn = validColumns[0];
  let bestColumns: number[] = [];

  // Adjust depth based on game state
  const adjustedDepth = state.dropCount > 0 ? Math.min(depth, 4) : depth;

  // 1. Check for immediate wins
  for (const col of validColumns) {
    const simulated = simulateMove(state, col);
    if (
      checkWinCondition(
        simulated.board,
        simulated.lastMove.row,
        simulated.lastMove.col
      )
    ) {
      return col;
    }
  }

  // 2. Check for opponent threats
  const threatAnalysis = analyzeThreats(state, aiPlayerId, 2);
  if (threatAnalysis.immediateThreat) {
    const winningResponse = findWinningResponseAfterBlock(
      state,
      threatAnalysis.blockColumn
    );
    if (winningResponse !== -1) return winningResponse;
    return threatAnalysis.blockColumn;
  }

  // 3. Enhanced minimax with threat detection
  for (const col of validColumns) {
    const simulated = simulateMove(state, col);
    const currentScore = minimax({
      state: simulated,
      depth: adjustedDepth - 1,
      alpha: -Infinity,
      beta: Infinity,
      isMaximizingPlayer: false,
      currentPlayerId: aiPlayerId,
    });

    // Enhanced positional evaluation
    const centerCol = Math.floor(state.board[0].length / 2);
    const centerDist = Math.abs(col - centerCol);
    const centerBonus = CENTER_COLUMN_BONUS / (centerDist + 1);
    const edgePenalty =
      col === 0 || col === state.board[0].length - 1 ? EDGE_PENALTY : 0;
    const mobility = getValidColumns(simulated.board).length * MOBILITY_FACTOR;
    const threatScore =
      evaluateThreatPotential(simulated.board, aiPlayerId) * THREAT_MULTIPLIER;
    const dropScore =
      evaluateDropPotential(simulated.board, aiPlayerId) *
      DROP_POTENTIAL_MULTIPLIER;

    const totalScore =
      currentScore +
      centerBonus +
      edgePenalty +
      mobility +
      threatScore +
      dropScore;

    if (totalScore > bestScore) {
      bestScore = totalScore;
      bestColumns = [col];
    } else if (totalScore === bestScore) {
      bestColumns.push(col);
    }
  }

  return (
    bestColumns[Math.floor(Math.random() * bestColumns.length)] || bestColumn
  );
};

// Threat analysis functions
function analyzeThreats(
  state: GameState,
  aiPlayerId: PlayerID,
  lookaheadDepth: number
) {
  // Check immediate threats
  const immediateThreat = canOpponentWinNext(state, aiPlayerId);
  if (immediateThreat.found) {
    return {
      immediateThreat: true,
      blockColumn: immediateThreat.blockColumn,
      potentialThreats: [],
    };
  }

  // Check potential threats
  const potentialThreats = findPotentialThreats(
    state,
    aiPlayerId,
    lookaheadDepth
  );
  return {
    immediateThreat: false,
    potentialThreats,
  };
}

function canOpponentWinNext(state: GameState, currentPlayerId: PlayerID) {
  const opponentState = {
    ...state,
    currentPlayerIndex: getNextPlayerIndex(state),
  };

  for (const col of getValidColumns(opponentState.board)) {
    const opponentMove = simulateMove(opponentState, col);
    if (
      checkWinCondition(
        opponentMove.board,
        opponentMove.lastMove.row,
        opponentMove.lastMove.col
      )
    ) {
      return { found: true, blockColumn: col };
    }
  }
  return { found: false };
}

function findPotentialThreats(
  state: GameState,
  currentPlayerId: PlayerID,
  depth: number
) {
  const threats: { column: number; threatLevel: number }[] = [];
  const opponentState = {
    ...state,
    currentPlayerIndex: getNextPlayerIndex(state),
  };

  for (const col of getValidColumns(opponentState.board)) {
    let threatScore = 0;
    const simulated = simulateMove(opponentState, col);

    if (
      checkWinCondition(
        simulated.board,
        simulated.lastMove.row,
        simulated.lastMove.col
      )
    ) {
      threatScore += 1000;
    }

    if (depth > 1) {
      const futureThreats = findPotentialThreats(
        simulated,
        currentPlayerId,
        depth - 1
      );
      threatScore +=
        futureThreats.reduce((sum, t) => sum + t.threatLevel, 0) / 2;
    }

    if (threatScore > 0) {
      threats.push({ column: col, threatLevel: threatScore });
    }
  }

  return threats.sort((a, b) => b.threatLevel - a.threatLevel);
}

function findWinningResponseAfterBlock(state: GameState, blockColumn: number) {
  const blockedState = simulateMove(state, blockColumn);
  for (const col of getValidColumns(blockedState.board)) {
    const winningMove = simulateMove(blockedState, col);
    if (
      checkWinCondition(
        winningMove.board,
        winningMove.lastMove.row,
        winningMove.lastMove.col
      )
    ) {
      return col;
    }
  }
  return -1;
}

// Evaluation functions
function evaluateBoard(state: GameState, aiPlayerId: PlayerID): number {
  let score = 0;
  const size = state.board.length;

  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (state.board[row][col].type === "occupied") {
        const directions = [
          { dr: 0, dc: 1 },
          { dr: 1, dc: 0 },
          { dr: 1, dc: 1 },
          { dr: 1, dc: -1 },
        ];

        for (const { dr, dc } of directions) {
          const segment = checkSegment(
            state.board,
            row,
            col,
            dr,
            dc,
            aiPlayerId
          );
          score += evaluateSegmentImproved(segment, aiPlayerId);
        }
      }
    }
  }

  // Mobility and center control
  const validColumns = getValidColumns(state.board);
  score += validColumns.length * MOBILITY_FACTOR;

  const opponentState = {
    ...state,
    currentPlayerIndex: getNextPlayerIndex(state),
  };
  const opponentMoves = getValidColumns(opponentState.board).length;
  score -= opponentMoves * (MOBILITY_FACTOR / 2);

  const centerCol = Math.floor(size / 2);
  for (let row = 0; row < size; row++) {
    if (state.board[row][centerCol].type === "occupied") {
      if (state.board[row][centerCol].playerId === aiPlayerId) {
        score += CENTER_COLUMN_BONUS * (1 + (size - row) * 0.2);
      } else {
        score -= CENTER_COLUMN_BONUS * 0.5 * (1 + (size - row) * 0.1);
      }
    }
  }

  return score;
}

function evaluateSegmentImproved(
  segment: { aiCount: number; opponentCount: number; empty: number },
  aiPlayerId: PlayerID
) {
  const { aiCount, opponentCount, empty } = segment;

  if (aiCount === 4) return WIN_SCORE;
  if (opponentCount === 4) return LOSS_SCORE;

  if (opponentCount === 0) {
    switch (aiCount) {
      case 3:
        return empty >= 1 ? CONNECT3_SCORE * 1.5 : 0;
      case 2:
        return empty >= 2 ? CONNECT2_SCORE * 1.2 : 0;
      case 1:
        return empty >= 3 ? CONNECT2_SCORE * 0.2 : 0;
    }
  }

  if (aiCount === 0) {
    switch (opponentCount) {
      case 3:
        return empty >= 1 ? -CONNECT3_SCORE * 3 : 0;
      case 2:
        return empty >= 2 ? -CONNECT2_SCORE * 1.5 : 0;
      case 1:
        return empty >= 3 ? -CONNECT2_SCORE * 0.3 : 0;
    }
  }

  if (aiCount > 0 && opponentCount > 0) {
    return -Math.pow(opponentCount, 2) * 100;
  }

  return 0;
}

function evaluateThreatPotential(board: CellState[][], aiPlayerId: PlayerID) {
  let threatScore = 0;
  const size = board.length;

  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (board[row][col].type === "empty" && board[row][col].playable) {
        const tempBoard = cloneDeep(board);
        tempBoard[row][col] = {
          type: "occupied",
          playerId: aiPlayerId,
          playable: true,
        };

        if (checkWinCondition(tempBoard, row, col)) {
          threatScore += 1000;
        }

        const directions = [
          { dr: 0, dc: 1 },
          { dr: 1, dc: 0 },
          { dr: 1, dc: 1 },
          { dr: 1, dc: -1 },
        ];

        for (const { dr, dc } of directions) {
          const segment = checkSegment(tempBoard, row, col, dr, dc, aiPlayerId);
          if (segment.aiCount === 3 && segment.empty === 1) {
            threatScore += 500;
          }
        }
      }
    }
  }

  return threatScore;
}

function evaluateDropPotential(board: CellState[][], aiPlayerId: PlayerID) {
  let dropScore = 0;
  const size = board.length;

  for (let row = 0; row < size; row++) {
    for (let col = 0; col < size; col++) {
      if (board[row][col].type === "empty" && board[row][col].playable) {
        for (let dropRow = row + 1; dropRow < size; dropRow++) {
          if (board[dropRow][col].type !== "empty") {
            if (board[dropRow][col].playerId === aiPlayerId) {
              dropScore += 50;
            } else {
              dropScore -= 75;
            }
            break;
          }
        }
      }
    }
  }

  return dropScore;
}

// Helper functions
function getValidColumns(board: CellState[][]): number[] {
  const validColumns: number[] = [];
  for (let col = 0; col < board[0].length; col++) {
    if (applyGravity(board, col).changed) {
      validColumns.push(col);
    }
  }
  return validColumns;
}

function simulateMove(state: GameState, col: number) {
  const newState = cloneDeep(state);
  const { row, changed } = applyGravity(newState.board, col);
  if (!changed) throw new Error("Invalid move simulation");

  const playerId = newState.players[newState.currentPlayerIndex].id;
  newState.board[row][col] = { type: "occupied", playerId, playable: true };

  return {
    ...newState,
    currentPlayerIndex: getNextPlayerIndex(newState),
    lastMove: { row, col, playerId },
  };
}

function checkSegment(
  board: CellState[][],
  startRow: number,
  startCol: number,
  dr: number,
  dc: number,
  currentPlayerId: PlayerID
) {
  let aiCount = 0;
  let opponentCount = 0;
  let empty = 0;
  const size = board.length;

  for (let i = 0; i < 4; i++) {
    const row = startRow + i * dr;
    const col = startCol + i * dc;
    if (row < 0 || row >= size || col < 0 || col >= size) break;

    const cell = board[row][col];
    if (cell.type === "occupied") {
      if (cell.playerId === currentPlayerId) aiCount++;
      else opponentCount++;
    } else if (cell.playable) {
      empty++;
    } else {
      break;
    }
  }

  return { aiCount, opponentCount, empty };
}

function minimax(params: MinimaxParams): number {
  const { state, depth, alpha, beta, isMaximizingPlayer, currentPlayerId } =
    params;

  if (depth === 0) return evaluateBoard(state, currentPlayerId);

  const validColumns = getValidColumns(state.board);
  if (validColumns.length === 0) return 0;

  if (state.lastMove) {
    const winCheck = checkWinCondition(
      state.board,
      state.lastMove.row,
      state.lastMove.col
    );
    if (winCheck) {
      return winCheck.cells[0].playerId === currentPlayerId
        ? WIN_SCORE + depth * 10000
        : LOSS_SCORE - depth * 10000;
    }
  }

  if (isMaximizingPlayer) {
    let maxEval = -Infinity;
    for (const col of validColumns) {
      const simulated = simulateMove(state, col);
      const evaluation = minimax({
        state: simulated,
        depth: depth - 1,
        alpha,
        beta,
        isMaximizingPlayer: false,
        currentPlayerId,
      });
      maxEval = Math.max(maxEval, evaluation);
      params.alpha = Math.max(params.alpha, evaluation);
      if (params.beta <= params.alpha) break;
    }
    return maxEval;
  } else {
    let minEval = Infinity;
    for (const col of validColumns) {
      const simulated = simulateMove(state, col);
      const evaluation = minimax({
        state: simulated,
        depth: depth - 1,
        alpha,
        beta,
        isMaximizingPlayer: true,
        currentPlayerId,
      });
      minEval = Math.min(minEval, evaluation);
      params.beta = Math.min(params.beta, evaluation);
      if (params.beta <= params.alpha) break;
    }
    return minEval;
  }
}
