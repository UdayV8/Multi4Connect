// Core game types and interfaces

export type PlayerID = number; // Range 1-8

export type CellState =
  | { type: "empty"; playable: true }
  | { type: "occupied"; playerId: PlayerID; playable: true }
  | { type: "blocked"; playable: false };

export type BoardSize = 10 | 12 | 14;

export type GameConfig = {
  playerCount: 4 | 6 | 8;
  isSinglePlayer: boolean;
  aiDifficulty?: "medium" | "hard"; // Only relevant for single player
};

export type Player = {
  id: PlayerID;
  color: string;
  isAI: boolean;
  isActive: boolean;
  hasWon: boolean;
  connect3s: number; // For tiebreaker
  winsAtMove?: number; // For tiebreaker if same connect3s
};

export type GameState = {
  board: CellState[][];
  players: Player[];
  currentPlayerIndex: number;
  gamePhase: "playing" | "finished";
  dropCount: number;
  winners: PlayerID[];
  moveHistory: { playerId: PlayerID; col: number }[];
};

export type WinCondition = {
  type: "horizontal" | "vertical" | "diagonal";
  cells: { row: number; col: number }[];
};

export type GameActionResult = {
  newState: GameState;
  winningLines?: WinCondition[];
  droppedBoard?: boolean;
};

// Utility types for AI
export type EvaluatedMove = {
  column: number;
  score: number;
  immediateWin?: boolean;
};

export type MinimaxParams = {
  state: GameState;
  depth: number;
  alpha: number;
  beta: number;
  maximizingPlayer: boolean;
  currentPlayerId: PlayerID;
};
